<?php
// использую классы из namespace Core
use Core\Session;
use Core\ValidationException;

// Определил корневую папку
const BASE_PATH = __DIR__.'/../';

// Начинаю сессию пользователя.
// Сессия - это период активности пользователя на сайте.
// Сессия ($_SESSION) массив, в котором храняться данные о пользователе.
// Время хранения устанавливается.
session_start();

// Подключаю необходимые для работы скрипты
require BASE_PATH . 'vendor/autoload.php';
require BASE_PATH . 'Core/functions.php';
require BASE_PATH . 'bootstrap.php';

// Создаю объект роутера
$router = new \Core\Router();
// Подключаю роуты
require BASE_PATH . 'routes.php';

// Выбираю из uri путь
$uri = parse_url($_SERVER['REQUEST_URI'])['path'];
// Если на странице просмотра есть скрытый input с параметром _method,
// то передаю его значение как метод для роута.
// Если скрытого inputa нет, то беру метод из запроса
$method = $_POST['_method'] ?? $_SERVER['REQUEST_METHOD'];


try {
    // Передаю в роутер путь и метод из формы
    $router->route($uri, $method);

    // Действия в случае появления ошибки
} catch (ValidationException $exception) {
    // Записываю в поле ['_flash'] файла $_SESSION ошибки
    Session::flash('errors', $exception->errors);

    // Записываю в поле ['_flash'] файла $_SESSION данные введенные в форму с ключем old
    Session::flash('old', $exception->old);

    // Возвращаю на предыдущую страницу
    return redirect($router->previousUrl());
}

// Удаляю из $_SESSION поле ['_flash'] с записанной вручную ошибкой в файле session/store.php
Session::unflash();
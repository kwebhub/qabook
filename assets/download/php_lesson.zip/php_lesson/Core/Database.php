<?php
// объявил namespace
namespace Core;

// использую класс из ядра РНР
use PDO;

class Database
{
    // Определяю доступные во всём классе переменные
    public $connection;
    public $statement;

    // Автоматическая инициализация PDO (PHP Database Object)
    public function __construct($config, $username = 'root', $password = '')
    {
        // Формирую запрос в БД с помощью конфига
        $dsn = 'mysql:' . http_build_query($config, '', ';');

        // Запихнул объект PDO в свойство connection своего класса
        $this->connection = new PDO($dsn, $username, $password, [
           PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
        ]);
    }

    // Запрос
    public function query($query, $params = [])
    {
        // Готовлю запрос с помощью объекта PDO
        $this->statement = $this->connection->prepare($query);

        // Выполняю запрос
        $this->statement->execute($params);

        // Возвращаю объект с выполнением запроса в свойстве statement
        return $this;
    }

    // Получить всё
    public function get()
    {
        // Возвращает результат запроса в БД от моего объекта
        return $this->statement->fetchAll();
    }

    // Получиьт что-то одно
    public function find()
    {
        // Возвращает результат запроса в БД от моего объекта
        return $this->statement->fetch();
    }

    // Если что-то получено из БД, то возвращает то что получил
    // Если из БД ничего не получено, то прерывает выполнение и пренаправляет на страницу кода статуса
    public function findOrFail()
    {
        $result = $this->find();

        if (! $result) {
            abort();
        }

        return $result;
    }
}

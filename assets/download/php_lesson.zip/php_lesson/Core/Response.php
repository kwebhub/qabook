<?php
// объявил namespace
namespace Core;

// Коды статуса через поля класса
class Response {
    const NOT_FOUND = 404;
    const FORBIDDEN = 403;
}
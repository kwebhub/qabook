<?php
// объявил namespace
namespace Core;

// Получает email и password от login формы
// Находит пользователя в БД по email
// Сверяет password
// Записывает в $_SESSION
class Authenticator
{
    // Получаю email и password от login формы
    // Ищу пользователя в БД по email
    public function attempt($email, $password)
    {
        // Сохраняю в переменную результат поиска пользователя в БД по email
        $user = App::resolve(Database::class)
            ->query('select * from users where email = :email', [
            'email' => $email
        ])->find();

        // Если в БД найден пользователь по email
        if ($user) {
            // password_verify - РНР функция сверяет шифрованный пароль из БД с паролем из login формы
            if (password_verify($password, $user['password'])) {

                // Записываю введенный пользователем email в $_SESSION
                // и обновляю id $_SESSION и cookie
                $this->login([
                    'email' => $email
                ]);

                // Возвращаю ответ залогинился ли пользователь
                return true;
            }
        }

        return false;
    }

    // Записываю введенный пользователем email в $_SESSION
    // и обновляю id $_SESSION и cookie
    public function login($user)
    {
        $_SESSION['user'] = [
            'email' => $user['email']
        ];

        // РНР функция удаляет старые файлы $_SESSION
        // присваивает новый id для $_SESSION и cookie в целях безопасности
        session_regenerate_id(true);
    }

    // Удаляю данные о сессии пользователя
    public function logout()
    {
        // Функция destroy() из файла Session.php
        Session::destroy();
    }
} 
<?php
// объявил namespace
namespace Core;

class Session
{
    // Проверяю содержит ли $_SESSION указанный ключ
    public static function has($key)
    {
        // Конвертирую в true or false полученный результат
        return (bool) static::get($key);
    }

    // Записать данные в файл $_SESSION
    public static function put($key, $value)
    {
        $_SESSION[$key] = $value;
    }

    // Получить данные из файла $_SESSION
    // Либо с полем ['_flash'], либо без него, либо ничего
    public static function get($key, $default = null)
    {
        return $_SESSION['_flash'][$key] ?? $_SESSION[$key] ?? $default;
    }

    // Записываю в поле ['_flash'] файла $_SESSION ассоциированный массив
    // Поле ['_flash'] позволяет хранить данные, которые можно удалить отдельно
    // без удаления $_SESSION
    public static function flash($key, $value)
    {
        $_SESSION['_flash'][$key] = $value;
    }
 
    // Удаляю из $_SESSION поле с записанной вручную ошибкой в файле session/store.php
    // Вызов функции в public/index.php
    public static function unflash()
    {
        // РНР функция очищает значение поля
       unset($_SESSION['_flash']);
    }

    // Очищаю $_SESSION
    public static function flush()
    {
        // Записываю в $_SESSION пустое значение
        $_SESSION = [];
    }

    // Удаляю данные о сессии пользователя
    public static function destroy()
    {
        static::flush();

        // РНР функция удаляет $_SESSION
        session_destroy();

        // РНР функция возвращает параметры cookie
        $params = session_get_cookie_params();

        // РНР функция устанавливает заданные значения в параметры cookie
        setcookie('PHPSESSID', '', time() - 3600, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
    }
} 
<?php
// объявил namespace
namespace Core\Middleware;

class Authenticated
{
    // Если не авторизован, то переход на главную страницу
    public function handle()
    {
        if (! $_SESSION['user'] ?? false) {
            header('location: /');
            exit();
        }
    }
}
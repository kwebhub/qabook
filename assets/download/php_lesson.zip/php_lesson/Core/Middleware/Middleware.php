<?php
// объявил namespace
namespace Core\Middleware;

class Middleware
{
    // Ключам из routes.php задаю классы из Core\Middleware
    public const MAP = [
        'guest' => Guest::class,
        'auth' => Authenticated::class
    ];

    public static function resolve($key)
    {
        // Выйти из скрипта если значение ключа роута NULL
        if (!$key) {
            return;
        }

        // Если по этому ключу есть класс в массиве классов МАР,
        // то запихиваю класс в переменную $middleware, если нет, то запихиваю false
        $middleware = static::MAP[$key] ?? false;

        // Если $middleware false, то выбрасываю ошибку
        if (!$middleware) {
            throw new \Exception("No matching middleware found for key '{$key}'.");
        }

        // создаю объект выбранного по ключу класса и вызываю его handle()
        (new $middleware)->handle();
    }
}
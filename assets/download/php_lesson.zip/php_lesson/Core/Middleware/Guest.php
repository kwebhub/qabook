<?php
// объявил namespace
namespace Core\Middleware;

class Guest
{
    public function handle()
    {
        // Если авторизован, то переход на главную страницу
        if ($_SESSION['user'] ?? false) {
            header('location: /');
            exit();
        }
    }
}
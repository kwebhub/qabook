<?php
// объявил namespace
namespace Core;

use Core\Middleware\Authenticated;
use Core\Middleware\Guest;
use Core\Middleware\Middleware;

class Router
{
    // переменная для всего класса, 
    protected $routes = [];

    // Добавляет роуты в массив
    public function add($method, $uri, $controller)
    {
        $this->routes[] = [
            'uri' => $uri,
            'controller' => $controller,
            'method' => $method,
            'middleware' => null
        ];

        return $this;
    }

    public function get($uri, $controller)
    {
        return $this->add('GET', $uri, $controller);
    }

    public function post($uri, $controller)
    {
        return $this->add('POST', $uri, $controller);
    }

    public function delete($uri, $controller)
    {
        return $this->add('DELETE', $uri, $controller);
    }

    public function patch($uri, $controller)
    {
        return $this->add('PATCH', $uri, $controller);
    }

    public function put($uri, $controller)
    {
        return $this->add('PUT', $uri, $controller);
    }

    // Проверяет ключ из файла routes.php
    public function only($key)
    {
        // array_key_last() - РНР функция, которая возвращает ключ последней записи в массиве
        // Сохраняю полученный ключ в поле middleware последней записи в массиве роутов
        $this->routes[array_key_last($this->routes)]['middleware'] = $key;

        return $this;
    }

    // По $uri, $method из index.php ищет в массиве роутов нужный контроллер
    public function route($uri, $method)
    {
        foreach ($this->routes as $route) {
            if ($route['uri'] === $uri && $route['method'] === strtoupper($method)) {
                // Значение поля middleware из роута передаю в функцию resolve из Core\Middleware\Middleware
                Middleware::resolve($route['middleware']);

                // Перенаправил на нужный контроллер
                return require base_path('Http/controllers/' . $route['controller']);
            }
        }

        $this->abort();
    }

    // Получаю uri откуда был переход
    public function previousUrl()
    {
        return $_SERVER['HTTP_REFERER'];
    }

    // Отрапляю клиенту код статуса и направляю на страницу просмотра
    protected function abort($code = 404)
    {
        http_response_code($code);

        require base_path("views/{$code}.php");

        die();
    }
}

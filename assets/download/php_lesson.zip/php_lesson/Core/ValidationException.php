<?php
// объявил namespace
namespace Core;

// Создаю свой класс ошибок и наследуюсь от РНР класса Exception
class ValidationException extends \Exception
{
    // Создаю массив ошибок и старых данных
    public readonly array $errors;
    public readonly array $old;

    // Выбрасываю ошибку с сообщением и содержимым массива ошибок и старых данных
    public static function throw($errors, $old)
    {
        // Создаю объект внутри класса
       $instance = new static('The form failed to validate.');

       $instance->errors = $errors;
       $instance->old = $old;

       throw $instance;
    }
} 
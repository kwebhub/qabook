<?php
// объявил namespace
namespace Core;

// Валидирую значение поля ввода текста
class Validator
{
    // Проверяю допустимую длину текста
    public static function string($value, $min = 1, $max = INF) //INF - infinity
    // public static function - это функция, которую можно вызывать как свойство класса без создания объекта
    {
        // Очищаю значение поля ввода текста от пробелов перед и после текста
        $value = trim($value);

        // измеряю длину текста и сравниваю с допустимыми значениями
        return strlen($value) >= $min && strlen($value) <= $max;
    }

    // Проверяю введённую при регистрации почту
    public static function email(string $value): bool //?
    {
        // РНР функция проверяет значение $value по встроенному фильтру FILTER_VALIDATE_EMAIL
        // Другие фильтры в документации
        // Возвращает email если $value содержит email или false если $value не содержит email
        return filter_var($value, FILTER_VALIDATE_EMAIL);
    }

    public static function greaterThan(int $value, int $greaterThan): bool
    {
        return $value > $greaterThan;
    }
} 

<?php
// объявил namespace
namespace Core;

use Exception;

class Container
{
    // Хранилище контейнера
    protected $bindings = [];

    // Добавить в контейнер
    // Привязать функцию к ключу массива
    // Смотри bootstrap.php
    public function bind($key, $resolver)
    {
        $this->bindings[$key] = $resolver;
    }

    // Взять из контейнера функцию по ключу
    /**
     * @throws Exception
     */
    public function resolve($key)
    {
        // Если такого ключа в массиве нет, то выбрасить ошибку
        if (!array_key_exists($key, $this->bindings)) {
            throw new Exception("No matching binding found for {$key}");
        }

        // Сохранить функцию в переменную
        $resolver = $this->bindings[$key];

        // РНР функция вызывает данную ей функцию
        return call_user_func($resolver);
    }
}
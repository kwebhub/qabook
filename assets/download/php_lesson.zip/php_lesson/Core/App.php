<?php
// объявил namespace
namespace Core;

class App
{
    // Переменная для контейнера
    protected static $container;

    // Впихиваю контейнер в свойство класса
    public static function setContainer($container)
    {
        static::$container = $container;
    }

    // Возвращаю контейнер из переменной
    public static function container()
    {
        return static::$container;
    }

    // Передаю $key, $resolver в функцию bind() из Container.php
    public static function bind($key, $resolver)
    {
        static::container()->bind($key, $resolver);
    }

    // Передаю $key в функцию resolve() из Container.php
    public static function resolve($key)
    {
        return static::container()->resolve($key);
    }
}

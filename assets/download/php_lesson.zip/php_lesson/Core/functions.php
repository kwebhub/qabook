<?php
// Беру обозначение кодов статуса
use Core\Response;

// Вывожу содержимое переменной в читабельном виде
function dd($value)
{
    echo "<pre>";
    var_dump($value);
    echo "</pre>";

    die();
}

// Проверяю является ли страница активной
function urlIs($value)
{
    return $_SERVER['REQUEST_URI'] === $value;
}

// Прерываю выполнение отсылаю код статуса и перевожу на страницу кода статуса
function abort($code = 404)
{
    http_response_code($code);

    require base_path("views/{$code}.php");

    die();
}

// Если условие правда, то возвращаю true, если нет то вызываю аbort($status) и передаю код статуса
function authorize($condition, $status = Response::FORBIDDEN)
{
    if (! $condition) {
        abort($status);
    }

    return true;
}

// Формирую абсолютный путь из переданного относительного
function base_path($path)
{
    // BASE_PATH - константа определена в файле public/index.php
    // содержит путь к корневой папке
    return BASE_PATH . $path;
}
// Принимает путь к файлу страницы просмотра и значения переменных для неё
// Вызывает страницу просмотра и передаёт на неё значение переменных
function view($path, $attributes = [])
{
    // РНР функция extract() импортирует значения из массива в переменные
    extract($attributes);

    require base_path('views/' . $path);
}

// Перенаправляю пользователя по указанному пути
function redirect($path)
{
    header("location: {$path}");
    exit();
}

// Получаю из массива old в $_SESSION['_flash'] данные введенные в форму
function old($key, $default = '')
{
    return Core\Session::get('old')[$key] ?? $default;
}
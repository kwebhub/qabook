<?php
// объявил namespace
namespace Http\Forms;

// использую классы из namespace Core
use Core\ValidationException;
use Core\Validator;

class LoginForm
{
    // Объявил массив для ошибок
    protected $errors = [];

    // При загрузке РНР автоматически создаю объект проверки аттрибутов полученных из файла session/store.php
    public function __construct(public array $attributes)
    {
        // Проверяю email в Validator.php
        if (!Validator::email($attributes['email'])) {
            $this->errors['email'] = 'Please provide a valid email address.';
        }

        // Проверяю password в Validator.php
        if (!Validator::string($attributes['password'])) {
            $this->errors['password'] = 'Please provide a valid password.';
        }
    }

    // Получил массив аттрибутов из файла session/store.php
    public static function validate($attributes)
    {
        // Создаю объект с результатами проверок внутри класса и
        // сохраняю объект результатов проверки в переменную
        $instance = new static($attributes);

        // Если массив ошибок в объекте результатов проверки не пустой,
        // то выбрасываю ошибку.
        // Если пустой, то возвращаю сам объект результатов проверки
        return $instance->failed() ? $instance->throw() : $instance;
    }

    // Выбрасываю ошибку и передаю массив с ошибками и данные введенные в форму
    public function throw()
    {
        ValidationException::throw($this->errors(), $this->attributes);
    }

    // Проверяю есть ли что-то в массиве ошибок
    public function failed()
    {
        return count($this->errors);
    }

    // возвращаю массив ошибок
    public function errors()
    {
        return $this->errors;
    }

    // Записываю новую ошибку из session/store.php
    // и возвращаю объект формы с массивом ошибок
    public function error($field, $message)
    {
        $this->errors[$field] = $message;

        return $this;
    }
}  
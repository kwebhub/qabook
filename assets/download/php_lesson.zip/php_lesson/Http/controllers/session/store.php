<?php
// использую классы из namespace Core
use Core\Authenticator;
use Http\Forms\LoginForm;

// Передаю аттрибуты в функцию validate() из файла LoginForm.php
$form = LoginForm::validate($attributes = [
    'email' => $_POST['email'],
    'password' => $_POST['password']
]);

// Создаю обект класса Authenticator.php
// Получаю от функции attempt() из Authenticator.php ответ: авторизован или нет
$signedIn = (new Authenticator)->attempt(
    $attributes['email'], $attributes['password']
);

// Если не авторизован, то записываю в массив ошибок LoginForm.php новую ошибку и выбрасываю её
if (!$signedIn) {
    $form->error(
        'email', 'No matching account found for that email address and password.'
    )->throw();
}

// Перенаправляю пользователя на главную
redirect('/');

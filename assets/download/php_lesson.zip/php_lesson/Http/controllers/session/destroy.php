<?php
// использую классы из namespace Core\Authenticator
use Core\Authenticator;

// Очищаю $_SESSION и cookie
(new Authenticator)->logout();

// Перенапраляю на главную
header('location: /');
exit();
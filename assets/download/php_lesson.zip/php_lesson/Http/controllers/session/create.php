<?php
// использую классы из namespace Core\Session
use Core\Session;

// Перенаправляю на страницу просмотра формы входа и передаю ошибки
view('session/create.view.php', [
    // Получаю из $_SESSION массив с ошибками
    'errors' => Session::get('errors')
]);
 
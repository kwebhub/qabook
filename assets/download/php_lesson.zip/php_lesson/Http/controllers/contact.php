<?php
// Передаю в функцию из core/functions.php
// файл страницы просмотра и переменную со значением 
view("contact.view.php", [
    'heading' => 'Contact Us',
]);
<?php
// использую классы из namespace Core
use Core\App;
use Core\Authenticator;
use Core\Database;
use Core\Validator;

// Получаю из контейнера объект БД с параматрами из config.php
// Database::class - РНР синтаксис, возвращает строку - путь к классу
$db = App::resolve(Database::class);
 
// Получаю из запроса email и password, которые ввёл пользователь
$email = $_POST['email'];
$password = $_POST['password'];

$errors = [];

// Если пользователь ввёл неформатный email, то записываю в массив ошибку
if (!Validator::email($email)) {
   $errors['email'] = 'Please provide a valid email address.';
}

// Если пользователь ввёл неформатный password, то записываю в массив ошибку
if (!Validator::string($password, 7, 255)) {
    $errors['password'] = 'Please provide a password of at least seven characters.';
}

// Если массив не пустой, то вывожу ошибку настраницу просмотра
if (! empty($errors)) {
    return view('registration/create.view.php', [
        'errors' => $errors
    ]);
}

// Нахожу пользователя в БД по email
$user = $db->query('select * from users where email = :email', [
    'email' => $email
])->find();

// Если пользователь в БД существует, то перенаправляю на главную
if ($user) {
    header('location: /');
    exit();
} else {
    // Если такого email в БД нет, то записываю в БД email и password нового пользователя
    $user = $db->query('INSERT INTO users(email, password) VALUES(:email, :password)', [
        'email' => $email,

        // РНР функция password_hash() шифрует пароль пользователя по алгоритму PASSWORD_BCRYPT
        'password' => password_hash($password, PASSWORD_BCRYPT)
    ]);

    // Пеердаю в функцию login() введенный пользователь email
    // для записи в $_SESSION
    (new Authenticator)->login(['email' => $email]);

    // Перенапраляю на главную
    header('location: /');
    exit();
}
 
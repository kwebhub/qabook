<?php
// использую классы из namespace Core
use Core\App;
use Core\Validator;
use Core\Database;

// Получаю из контейнера объект БД с параматрами из config.php
// Database::class - РНР синтаксис, возвращает строку - путь к классу
$db = App::resolve(Database::class);

// Схема процесса:
// страница просмотра views/edit.view.php по нажатию кнопки формы
// отправляет запрос, который содержит $uri, $method
// index.php выделяет $uri, $method из запроса и отдаёт их объекту класса Router.php
// объект класса Router.php ($router) по $uri, $method ищет в массиве роутов нужный контроллер
// и перенаправляет на него согласно методам в routes.php
// контроллер обрабатывает заметку согласно id заметки и синхронизирует с БД
// перенаправляет на страницу просмотра


// Создал массив для сообщений об ошибке
$errors = [];

// Проверяю длину текста от 1 до 1000 символов, вызываю без создания объекта Validator::string()- функция как свойство класса
if (! Validator::string($_POST['body'], 1, 1000)) {
    // Записал сообщение об ошибке в массив
    $errors['body'] = 'A body of no more than 1,000 characters is required.';
}

// Если в массиве ошибок есть сообщение, то перейти на страницу просмотра и передать массив с сообщением
if (! empty($errors)) {
    return view("notes/create.view.php", [
        'heading' => 'Create Note',
        'errors' => $errors
    ]);
}

// Добавляю заметку в БД. Значения отдельными параметрами для безопасности
$db->query('INSERT INTO notes(body, user_id) VALUES(:body, :user_id)', [
    'body' => $_POST['body'],
    'user_id' => 1
]);

// Перейти на страницу заметок
header('location: /notes');
die();

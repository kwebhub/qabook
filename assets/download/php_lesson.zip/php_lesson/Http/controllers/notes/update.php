<?php
// использую классы из namespace Core
use Core\App;
use Core\Database;
use Core\Validator;

// Получаю из контейнера объект БД с параматрами из config.php
// Database::class - РНР синтаксис, возвращает строку - путь к классу
$db = App::resolve(Database::class);

// id пользователя
$currentUserId = 222221;

// Схема процесса:
// страница просмотра views/edit.view.php по нажатию кнопки формы
// отправляет запрос, который содержит $uri, $method
// index.php выделяет $uri, $method из запроса и отдаёт их объекту класса Router.php
// объект класса Router.php ($router) по $uri, $method ищет в массиве роутов нужный контроллер
// и перенаправляет на него согласно методам в routes.php
// контроллер обрабатывает заметку согласно id заметки и синхронизирует с БД
// перенаправляет на страницу просмотра


// Запрашиваю из БД заметку по id из файла views/edit.view.php
// Если заметка получена то продолжаем выполнение, если нет то прерывает выполнение
// и перенаправляет на страницу с кодом статуса
$note = $db->query('select * from notes where id = :id', [
    'id' => $_POST['id']
])->findOrFail();

// Проверка совпадает ли id автора заметки с id пользователя
// Если да, то продолжает выполнение, если нет то прерывает выполнение
// и перенаправляет на страницу с кодом статуса
authorize($note['user_id'] === $currentUserId);

// Создал массив для сообщений об ошибке
$errors = [];

// Проверяю длину текста от 1 до 1000 символов
if (! Validator::string($_POST['body'], 1, 10)) {
    $errors['body'] = 'A body of no more than 1,000 characters is required.';
}

// Если в массиве ошибок есть сообщение, то перейти на страницу просмотра редактирования и передать массив с сообщением
if (count($errors)) {
    return view('notes/edit.view.php', [
        'heading' => 'Edit Note',
        'errors' => $errors,
        'note' => $note
    ]);
}

// Обновить заметку в БД. Значения отдельными параметрами для безопасности
$db->query('update notes set body = :body where id = :id', [
    'id' => $_POST['id'],
    'body' => $_POST['body']
]);

// Перейти на страницу заметок
header('location: /notes');
die();
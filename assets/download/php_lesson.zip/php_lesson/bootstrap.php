<?php
// подключаю классы из namespace Core
use Core\App;
use Core\Container;
use Core\Database;

// создал объект контейнера
$container = new Container();

// Core\Database - ключ в массиве контейнера для вызова
// функции создания объекта БД
$container->bind('Core\Database', function () {
    // Беру параметры БД из config.php
    $config = require base_path('config.php');

    // Возвращаю объект БД с параматрами из config.php
    return new Database($config['database']);
});

// Впихнул объект контейнера в свойство Арр класса
App::setContainer($container);
